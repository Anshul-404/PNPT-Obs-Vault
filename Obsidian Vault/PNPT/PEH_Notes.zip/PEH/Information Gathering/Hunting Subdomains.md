1. `sublist3r`: Tool
	- `sudo apt install sublis3r`
2. `crt.sh`: Website
	- `%` -> wildcard
	- `%.tesla.com` -> Finds certificates using that domains
3. OWASP Amass: Github Project
	- 