1. `www.builtwith.com`
	- Enter website address to find frameworks and technologies in use.
2. `wappalyzer`: Firefox extension
3. `whatweb`: Tool
	- `whatweb https://tesla.com`