- Find information through responses while clicking around the website. For example:
![[burp_info_gathering.png]]