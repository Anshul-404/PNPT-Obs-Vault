1. `breach-parse` - Heath Adams
	- usage: `./breah-parse.sh @tesla.com tesla.txt`
	- `tesla-master.txt`: username and password
	- `tesla-passwords.txt`: passwords
	- `tesla-users.txt`: usernames
2. `www.dehashed.com` - Paid Website
	- Search by passwords, emails and store them
	- Social engineer by address, contact, etc