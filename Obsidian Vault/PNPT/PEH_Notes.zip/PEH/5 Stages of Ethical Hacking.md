1. **Reconnaissance:**
	- Active: Interacting with the target directly. For eg. nmap, nikto, nessus, etc.
	- Passive: Not interacting with target directly. For eg. looking Profile, Company products, website,etc
2. **Scanning & Enumeration:**
	- Interacting with the target directly. For eg. nmap, nikto, nessus, etc.
	-  Finding vulnerabilities, open ports, value targets, information, etc.
3. **Gaining Access:**
	- Exploiting the target and gaining access.
4. **Maintaining Access:**
	- Post exploitation phase to maintain persistence access on the target or network.
5. **Covering Tracks:**
	- Clearing exploits, binaries, files you used, etc.