- We have an account, **now what to do**?
- How to **move** **laterally and vertically** after getting initial access?
![[Pasted image 20250330145222.png]]
Rinse and Repeat
---
- Always do multitasking, ==start with **quick wins**== **`Kerberoasting`**
- We **don't need shells** on machines, we can **==just dump credentials and hashes==**
- Try these `hashes` on **all the other machines**.

Enumerate
---
- **What our accounts have access to?**
- **What other users / Computers are there?**
- **Emails? Passwords? Files?**
