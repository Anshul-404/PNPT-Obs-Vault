---

---
1. Start with **Responder and mitm6**
	1. Run scans to **generate traffic** like nessus, nmap, etc scans
	2. Catching traffic in the **morning or after lunch** is good strategy.
2. If scans are taking **too long,** look for websites in scope (h**ttp_version :: msfconsole**)
	1. **Default credentials, common vulnerablities, easy logins,** login bypass, etc.
3. Look for **default credentials** on web logins
	2. **Printers**
	3. **Jenkins, etc.**
4. Thinking Out of the box
	1. Not always the above will work
	2. **==What else is available to us? Something different? Something weird? Something unusual?==**
