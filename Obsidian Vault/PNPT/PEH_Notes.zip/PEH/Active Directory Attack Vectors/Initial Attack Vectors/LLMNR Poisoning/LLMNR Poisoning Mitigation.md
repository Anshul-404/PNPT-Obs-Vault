- `Group Managemnet Policy`
	- `Turn off multicast name resolution
		![[Pasted image 20250328144100.png]]
- ![[Pasted image 20250328144120.png]]`