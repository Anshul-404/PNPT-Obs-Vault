https://appsecexplained.gitbook.io/appsecexplained
- **Follow checklists**
https://github.com/swisskyrepo/PayloadsAllTheThings/
- [XXE](https://github.com/swisskyrepo/PayloadsAllTheThings/)