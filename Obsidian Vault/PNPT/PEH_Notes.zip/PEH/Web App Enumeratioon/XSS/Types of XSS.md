- **Reflected**
---
	- When request comes from current `HTTP` request
	- **Script is included in the response from the server**
	- **==We can only target ourselves or if someone can click this to steal cookies.==**
	![[Pasted image 20250406060022.png]]

- **Stored**
---
	- When the **payload is included in the DB** and then retrieved later
	- **==If some user can view this, then this would be executed.==**
	- ![[Pasted image 20250406060242.png]]

- **DOM-Based**
---
- Client side has some vulnerable javascript inputs
- ![[Pasted image 20250406060434.png]]