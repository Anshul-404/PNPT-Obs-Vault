![[Pasted image 20250325030952.png]]
- administrator : Password456!
- IP Address : 192.168.157.129
![[Pasted image 20250325031133.png]]
- Nmap Results ->[[Nmap results for Blue]]