- Found `id_rsa` and username in [[NFS - 111, 2049]] and [[Initial Foothold (www-data)]]

# SSH 
---
- `ssh -i id_rsa jeanpaul@192.168.157.131`
![[Pasted image 20250325143034.png]]
- `I_love_java` was found in [[HTTP - 80]] and worked:
![[Pasted image 20250325143349.png]]