- IP Address: `192.168.157.131`
- Credentials for VM login:
	> root:tcm
- Nmap results -> [[Nmap results for Dev]]
- OS -> 
  ```
  Running: Linux 4.X|5.X, MikroTik RouterOS 7.X
	OS CPE: cpe:/o:linux:linux_kernel:4 cpe:/o:linux:linux_kernel:5 cpe:/o:mikrotik:routeros:7 cpe:/o:linux:linux_kernel:5.6.3OS details: Linux 4.15 - 5.19, OpenWrt 21.02 (Linux 5.4), MikroTik RouterOS 7.2 - 7.5 (Linux 5.6.3)
	```