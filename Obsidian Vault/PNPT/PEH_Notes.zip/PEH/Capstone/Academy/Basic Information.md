- Credentials for VM login:
	> root:tcm
- IP: `192.168.157.130`
- Nmap results [[Nmap results for Academy]]
