- Internal Penetration Testing: Being inside of network, looking out

![[Pasted image 20250326153240.png]]
# Phonebook for windows Terminology
---
- AD is storing information for us.
- This **==information is what we call `objects**`==. For example, users, printers, computers, etc.
- We can also ==use **AD to push out policies==**. For example, if we want to set password or minimum password length, we can do this with AD.
- AD is basically **==`identity management service**` by Microsoft==.

# Why Active Directory?
---
- AD has **==`features` that come comes (Microsoft ships)==** like exploits (not exactly). Unlike potato attacks or kernel exploits, **these aren't patched as they are features**.
- We are just abusing these features.
