# Domain Controller (HEAD HONCHO)
---
- If AD is a phonebook, **Domain controller is the host of that phonebook**.
- It provides ==**authorization and authentication**==.
- It can allow admin **a==ccess to manage user accounts and resources**.==
- We control **everything for our domain** with this (as name suggests).
- ![[Pasted image 20250326154041.png]]
# AD DS Data Store (Active Directory Domain Services)
---
- It contains all the database **information for our users, services and apps.**
- It contains a most important file called **==NTDS.dit==**
- We can pull a lot of information from this file, most importantly, **password hashes.**
- ![[Pasted image 20250326154257.png]]