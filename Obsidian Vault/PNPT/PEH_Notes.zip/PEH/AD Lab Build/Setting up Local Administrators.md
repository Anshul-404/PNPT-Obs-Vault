- Along with `fcastle` on Punisher and `pparker` on Spiderman, we also added another`Administrator : Password1!`user as `Administrators` member of  in `User Management` on each machine. ==This account was already present on Heath's machine, but since we used cloud, we had to add this one.==
- In `groups` setting, added `fcastle` on `ThePunisher`, `pparker` on Spiderman. These appear **differently compared to local accounts** as ==**these are from the domain now not local users.**==
- Also added,**`fcastle` on `Spiderman` machine in `Administrator` group.** (not vice versa).
- Added `kamran` as `Administrator` when we joined the `domain` and was asked for it i prompt.
- Mapped network drive on Spiderman of hackme as Z letter using `kamran` credentials.

![[Pasted image 20250328035244.png]]