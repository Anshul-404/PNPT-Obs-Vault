# Uncommon way of ssh (might be useful)
---
- ![[Pasted image 20250324145358.png]]
- Sometimes, there are banners, but no banners right now :(